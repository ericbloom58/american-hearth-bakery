-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2017 at 06:50 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ahb`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `blog` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `name`, `blog`, `created`, `modified`) VALUES
(1, 'test page 1', '<p>okjay<img class="" src="/files/random%20images/elitelacross.jpg" alt="" width="496" height="110" /></p>\r\n<p>okay</p>', '2017-06-30 15:07:06', '2017-06-30 15:07:06');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(14, 'Pastries', ''),
(12, 'Cookies', ''),
(13, 'Minis', ''),
(11, 'Cakes', ''),
(10, 'Bread', '');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `page_type` varchar(255) NOT NULL DEFAULT 'content',
  `linked_gallery` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `name`, `content`, `created`, `modified`, `page_type`, `linked_gallery`) VALUES
(9, 'About Us', '<p><span class="dropcap dropcap-default ">A</span>merican Heath Bakery began life in a downtown Baltimore kitchen in 1989 making fresh scones for local coffee shops. By 2008 it had grown (sometimes painfully) and evolved into a premier baker of 190 different items which consist of muffins, cookies, brownies, danish, pastries, N.Y. style bagels, sandwich bread, granola and much more. All made fresh six days a week. They are known as the pre-eminent DC/Baltimore bakery with the highest quality of such an extensive selection of baked goods, initially sold only wholesale to coffee shops, delicatessens, hospitals, universities and caterers. In 2007 the company began an eighteen month project to eliminate an extensive list of unacceptable food ingredients from its recipes without significantly increasing costs and without sacrificing flavor. By 2008 over 95% of its sales are now&nbsp;<strong>"Chemical Free", "All Natural" and with "No Artificial Flavors or Coloring".</strong>&nbsp;All products now have labels available with ingredients, nutritional values and bar codes. Early in 2008 they introduced their products packaged and labeled, available fresh, par-baked and frozen raw or fully baked to distributors, gourmet and whole food markets.&nbsp;<br /><br />American Hearth Bakery today is a multimillion dollar "small business\' Even in the most unstable economic times in the United States,&nbsp;<strong>the company has had no bank debt and pays all its bills in 7 days or less.</strong>&nbsp;It is owned by Kurt Miller who had been retired five years before buying the bakery in 2003, known then as A. Scone Co., as a challenge to retired life. Miller had to redesign and rebuild everything about the company. Replacing all the employees (except one, Paul Nygren, the manager and head baker), initiated modern bookkeeping, all new recipes and back-ups for all critical functions but most importantly creating an atmosphere where everybody can maximize their own personal potential in a "family" atmosphere where everybody looks forward to coming to work. They all work hard to please their customers and make them feel a part of the American Heath Bakery Team.</p>', '2017-07-20 11:56:43', '2017-07-20 12:56:26', 'content', ''),
(10, 'Home', '<p>Here is a short description about the local gem that is American Hearth Bakery</p>', '2017-07-20 12:03:12', '2017-07-26 18:34:10', 'content', ''),
(11, 'Unacceptable Ingredients', '<p>Our goal is to provide the highest quality, best tasting and safest products possible at an economical price. The Majority of our baked goods (although, not all) have no artificial additives, sweeteners, colorings, preservatives, or hydrogenated fats. Our "clean label" products have a heart printed on the label and on the price list. In addition, there are no peanuts or peanut products processed in any of our facilities. We also, buy and use cage free/hormone free dairy and poultry ingredients.</p>\r\n<p><br /><br /></p>\r\n<p>&nbsp;</p>\r\n<center><strong>Unacceptable Food Ingredients</strong></center>\r\n<p>&nbsp;</p>\r\n<div class="dt-sc-one-half column first">\r\n<ul>\r\n<li>acesulfame-K (acesulfame potassium)</li>\r\n<li>acetylated esters of mono- and diglycerides</li>\r\n<li>ammonium chloride</li>\r\n<li>artificial colors</li>\r\n<li>artificial flavors</li>\r\n<li>aspartame</li>\r\n<li>azodicarbonamide</li>\r\n<li>benzoates in foods</li>\r\n<li>benzoyl peroxide</li>\r\n<li>BHA (butylated hydroxyanisole)</li>\r\n<li>BHT (Butylated hydroxytoluene)</li>\r\n<li>bleached flour</li>\r\n<li>bromated flour</li>\r\n<li>brominated vegetable oil (BVO)</li>\r\n<li>calcium bromate</li>\r\n<li>calcium disodium EDTA</li>\r\n<li>calcium peroxide</li>\r\n<li>calcium propionate</li>\r\n<li>calcium saccharin</li>\r\n<li>calcium sorbate</li>\r\n<li>calcium stearoyl-2-lactylate</li>\r\n<li>DATEM (Diacetyl tartaric and fatty acid esters of mono and diglycerides)</li>\r\n<li>dimethylpolysiloxane</li>\r\n<li>dioctyl sodium sulfosuccinate (DSS)</li>\r\n<li>disodium calcium EDTA</li>\r\n<li>disodium dihydrogen EDTA</li>\r\n<li>disodium guanylate</li>\r\n<li>disodium inosinate</li>\r\n<li>EDTA</li>\r\n<li>ethyl vanillin</li>\r\n<li>ethylene oxide</li>\r\n<li>ethyoxyquin</li>\r\n<li>FD &amp; C colors</li>\r\n<li>GMP (disodium guanylate)</li>\r\n<li>High Fructose Corn Syrup</li>\r\n<li>hex-, hepta- and octa-esters of sucrose</li>\r\n<li>hydrogenated fats</li>\r\n<li>IMP (disodium inosinate)</li>\r\n<li>irradiated foods</li>\r\n</ul>\r\n</div>\r\n<div class="dt-sc-one-half column">\r\n<ul>\r\n<li>lactylated esters of mon- and</li>\r\n<li>diglycerides</li>\r\n<li>lead soldered cans</li>\r\n<li>methyl silicon</li>\r\n<li>methylparaben</li>\r\n<li>microparticularized whey protein derived fat substitute</li>\r\n<li>monosodium glutamate (MSG)</li>\r\n<li>natamyacin</li>\r\n<li>nitrates/nitrites</li>\r\n<li>partially hydrogenated oil</li>\r\n<li>polydextrose</li>\r\n<li>potassium benzoate</li>\r\n<li>potassium bisulfite</li>\r\n<li>potassium bromate</li>\r\n<li>potassium metabisulfite</li>\r\n<li>potassium sorbate</li>\r\n<li>propionates</li>\r\n<li>propyl gallate</li>\r\n<li>propylparaben</li>\r\n<li>saccharin</li>\r\n<li>soduium aluminum phosphate</li>\r\n<li>sodium aluminum sulfate</li>\r\n<li>sodium benzoate</li>\r\n<li>sodium bisulfite</li>\r\n<li>sodium diacetate</li>\r\n<li>sodium glutamate</li>\r\n<li>sodium nitrate/nitrite</li>\r\n<li>sodium propionate</li>\r\n<li>sodium stearoyl-2-lactylate</li>\r\n<li>sodium sulfite</li>\r\n<li>solvent extracted oils, as stand alone single-ingredient oils (except grapeseed oil)</li>\r\n<li>sorbic acid</li>\r\n<li>sucralose</li>\r\n<li>sucroglycerides</li>\r\n<li>sucrose polyester</li>\r\n<li>sulfites (sulfur dioxide)</li>\r\n<li>TBHQ (tertiary butylhydroquinone)</li>\r\n<li>tetrasodium EDTA</li>\r\n<li>vanillin</li>\r\n</ul>\r\n</div>', '2017-07-20 12:56:59', '2017-07-20 12:59:32', 'content', '');

-- --------------------------------------------------------

--
-- Table structure for table `flavors`
--

CREATE TABLE `flavors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flavors`
--

INSERT INTO `flavors` (`id`, `name`, `description`, `created`) VALUES
(6, 'Bobka Mini Chocolate', '3 1/2"', '2017-08-02 14:00:24'),
(5, 'Lemon', '', '2017-08-02 14:00:03'),
(4, 'Chocolate/White', '', '2017-08-02 13:59:56'),
(7, 'Apple Crumb', '', '2017-08-03 13:05:40'),
(8, 'Banana Nut', '', '2017-08-03 13:05:47'),
(9, 'Black Bottom', '', '2017-08-03 13:05:54'),
(10, 'Blueberry', '', '2017-08-03 13:05:59'),
(11, 'Apple Bran', '', '2017-08-03 13:06:07'),
(12, 'Blueberry Bran', '', '2017-08-03 13:06:13'),
(13, 'Cappucino Chocolate', '', '2017-08-03 13:06:19'),
(14, 'Carrot Rasin', '', '2017-08-03 13:06:26'),
(15, 'Cherry Crumb', '', '2017-08-03 13:06:32'),
(16, 'Cranberry', '', '2017-08-03 13:06:39'),
(17, 'Lemon Poppy', '', '2017-08-03 13:06:45'),
(18, 'Pumpkin', '', '2017-08-03 13:06:50'),
(19, 'Corn', '', '2017-08-03 13:06:53'),
(20, 'Cheese', '', '2017-08-03 13:06:57'),
(21, 'Zucchini Nut', '', '2017-08-03 13:07:02'),
(22, 'Double Chocolate Chip', '', '2017-08-03 13:07:09'),
(23, 'Black Bottom Cupcake', '', '2017-08-03 13:07:24'),
(24, 'Pumpkin Cheese', '', '2017-08-03 13:07:31'),
(25, 'Almond', '', '2017-08-03 13:11:35'),
(26, 'Almond Chocolate Dip', '', '2017-08-03 13:11:43'),
(27, 'Apple', '', '2017-08-03 13:11:49'),
(28, 'Apricot', '', '2017-08-03 13:11:53'),
(29, 'Poppy', '', '2017-08-03 13:11:58'),
(30, 'Prune', '', '2017-08-03 13:12:02'),
(31, 'Raspberry', '', '2017-08-03 13:12:07'),
(32, 'Chocolate', '', '2017-08-03 13:13:45'),
(33, 'Cherry', '', '2017-08-03 13:13:51'),
(34, 'Poppy Seed', '', '2017-08-03 13:14:00'),
(35, 'Cherry Cheese', '', '2017-08-03 13:15:12'),
(36, 'Lemon', '', '2017-08-03 13:15:44'),
(37, 'Peach', '', '2017-08-03 13:15:57'),
(38, 'Cinnamon', '', '2017-08-03 13:16:14'),
(39, 'Chocolate Almond', '', '2017-08-03 13:16:28'),
(40, 'Chocolate Raisin', '', '2017-08-03 13:16:39'),
(41, 'Coconut Custard', '', '2017-08-03 13:16:48'),
(42, 'Pineapple', '', '2017-08-03 13:17:08'),
(43, 'Raisin', '', '2017-08-03 13:17:35'),
(44, 'Chocolate Chunk', '', '2017-08-03 13:20:05'),
(45, 'Butter Pecan', '', '2017-08-03 13:20:10'),
(46, 'Iced Raisin Cinn', '', '2017-08-03 13:20:19'),
(47, 'Apple Cinnamon', '', '2017-08-03 13:20:46'),
(49, 'Cran Orange Walnut', '', '2017-08-03 13:21:13'),
(50, 'Mixed', '', '2017-08-03 13:21:24'),
(51, 'Elephant Ears', '', '2017-08-03 13:23:25'),
(52, 'Chocolate Cigar  Stick', '', '2017-08-03 13:23:41'),
(53, 'Raspberry Cigar Stick', '', '2017-08-03 13:23:55'),
(54, 'Cinnamon Cigar Stick', '', '2017-08-03 13:24:16'),
(55, 'Walnut Raisin Bobka', '', '2017-08-03 13:24:26'),
(56, 'Chocolate Almond Bobka', '', '2017-08-03 13:24:39'),
(57, 'Apple Turnover', '', '2017-08-03 13:24:51'),
(58, 'Cherry Turnover', '', '2017-08-03 13:24:58'),
(59, 'Apple Betty', '', '2017-08-03 13:25:05'),
(60, 'Peach Betty', '', '2017-08-03 13:25:12'),
(61, 'Apple Betty Large', '', '2017-08-03 13:25:50'),
(62, 'Coconut Mac. Plain', '', '2017-08-03 13:25:59'),
(63, 'Coconut Mac. Choco dip', '', '2017-08-03 13:26:15'),
(64, 'Maple Walnut Twist', '', '2017-08-03 13:26:31'),
(65, 'Cranberry Apple', '', '2017-08-03 13:28:25'),
(66, 'Banana Blueberry', '', '2017-08-03 13:28:37'),
(67, 'Zucchini', '', '2017-08-03 13:28:44'),
(68, 'French Nut', '', '2017-08-03 13:28:49'),
(69, 'Cinnamon Nut Sticks', '', '2017-08-03 13:31:21'),
(70, 'Rolled Sugar Crisp', '', '2017-08-03 13:31:28'),
(71, 'Bear Claws Apple', '', '2017-08-03 13:31:37'),
(72, 'Cheese Pockets', '', '2017-08-03 13:31:46'),
(73, 'Eclair', '', '2017-08-03 13:31:51'),
(74, 'Radial Bars', '', '2017-08-03 13:31:55'),
(75, 'Radial Bars Chocolate Mousse', '', '2017-08-03 13:32:03'),
(76, 'Medium Radial Bars', '', '2017-08-03 13:32:16'),
(77, 'Pecan Sticky', '', '2017-08-03 13:35:04'),
(78, 'Caramel Apple', '', '2017-08-03 13:35:12'),
(79, 'Large Apple Strudel', '', '2017-08-03 13:36:25'),
(80, 'Poppy Danish Strip', '', '2017-08-03 13:36:33'),
(81, 'Chocolate Danish Strip', '', '2017-08-03 13:36:41'),
(82, 'Plain Sandwich', '', '2017-08-03 13:38:36'),
(83, 'Plain French Butter', '', '2017-08-03 13:38:42'),
(84, 'Pecan*', 'Seasonal', '2017-08-03 13:48:07'),
(85, 'Pumpkin*', 'Seasonal', '2017-08-03 13:48:17'),
(86, '12-1 lb Snack Bars', '', '2017-08-03 13:49:51'),
(87, '24-3 oz Bars', '', '2017-08-03 13:50:02'),
(88, 'Blondie Plain', '', '2017-08-03 13:51:13'),
(89, 'Blondie w/ Nuts', '', '2017-08-03 13:51:21'),
(90, 'Cheesecake', '', '2017-08-03 13:51:34'),
(91, 'Plain', '', '2017-08-03 13:51:43'),
(92, 'Rockyroad', '', '2017-08-03 13:51:49'),
(93, 'Raspberry Cream', '', '2017-08-03 13:52:22'),
(94, 'Expresso Cheese', '', '2017-08-03 13:52:32'),
(95, 'Scones', '', '2017-08-03 13:59:52'),
(96, 'Eclairs', '', '2017-08-03 14:00:03'),
(97, 'Black Bott Cupcake', '1.2 oz', '2017-08-03 14:00:54'),
(98, 'Danish Mini', '', '2017-08-03 14:00:59'),
(99, 'Danish Medium', '', '2017-08-03 14:01:09'),
(100, 'Croissants (Plain)', 'Week Notice Needed', '2017-08-03 14:01:32'),
(101, 'Bagels (Plain)', '24 Hour Notice Needed', '2017-08-03 14:03:37'),
(102, 'Mini Betty - Apple', '', '2017-08-03 14:05:34'),
(103, 'Mini Betty - Peach', '', '2017-08-03 14:05:40'),
(104, 'Mini Cheese Pockets', '', '2017-08-03 14:05:52'),
(105, 'Mini Pecan Sticky Buns', '1 1/2"', '2017-08-03 14:06:11'),
(106, 'Mini Chocolate Top', '', '2017-08-03 14:18:54'),
(107, 'Mini Icebox', '', '2017-08-03 14:19:00'),
(108, 'Mini Linzer Cookie Apricot', '', '2017-08-03 14:19:13'),
(109, 'Mini Linzer Cookie Raspberry', '', '2017-08-03 14:19:25'),
(110, 'Mini Chocolate Mousse Cups', '', '2017-08-03 14:22:50'),
(111, 'Mini Eclairs', '', '2017-08-03 14:25:52'),
(112, 'Mini Kiwi Tarts', '', '2017-08-03 14:26:02'),
(113, 'Mini Mandarin Orange Tarts', '', '2017-08-03 14:26:14'),
(114, 'Mini Petit Fours', '', '2017-08-03 14:26:37'),
(115, 'Mini Strawberry Tarts', '', '2017-08-03 14:26:53'),
(116, 'Mini Chocolate Dipped Strawberres', '', '2017-08-03 14:27:03'),
(117, 'Mini White Chocolate Dipped Strawberries', '', '2017-08-03 14:27:19'),
(118, 'Mini Radial Bars', '', '2017-08-03 14:27:29'),
(119, 'Mixed Fruit Tort', '', '2017-08-03 14:27:38'),
(120, 'Petit Fours Large', '3"x3"x3"', '2017-08-03 14:28:10');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`) VALUES
(1, 'Dozen'),
(2, 'Pound'),
(3, 'Lb'),
(4, 'Each'),
(5, '4 oz'),
(6, '5 1/2 oz'),
(7, '1/4 Sheet'),
(9, 'Half Dozen'),
(10, '4"'),
(11, '10"'),
(12, 'Min.'),
(13, '1/2 Case'),
(14, '30 Case');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `body` longtext,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created`, `modified`, `user_id`) VALUES
(1, 'Test1', 'Testing', '2017-06-29 13:22:39', '2017-06-29 13:22:39', NULL),
(2, 'Test2', 'Testies', '2017-06-29 13:22:52', '2017-06-29 13:22:52', NULL),
(3, 'Test3', 'Tastey', '2017-06-29 13:23:09', '2017-06-29 13:23:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`) VALUES
(6, 'Hamentaschen', '<p>Rich and Dense</p>'),
(5, 'Muffins', ''),
(7, 'Danish', ''),
(8, 'Hamentashen', '<p>Light Butter, Flakey</p>'),
(9, 'Pastries', ''),
(10, 'Breakfast Breads', ''),
(11, 'Scone', '<p>5oz</p>'),
(12, 'Danish Sticks', ''),
(13, 'Mini Bobka', ''),
(15, 'Breakfast Items', ''),
(16, 'Jumbo Buns', ''),
(17, 'Bundt Cake', ''),
(18, 'Tarts', ''),
(19, 'Brownies', '<p>8"x12"</p>'),
(20, 'Granola', ''),
(21, 'Croissants', ''),
(22, 'Mini Muffins', '<p>2 oz</p>'),
(23, 'Minis', '<p>Assorted</p>'),
(24, 'Mini Hamentasch', '<p>Rich and Dense</p>'),
(25, 'Mini Cookies', ''),
(26, 'Mini French Pastries', '');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `category_id` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `product_id`, `category_id`) VALUES
(37, 6, 14),
(36, 5, 14),
(39, 7, 14),
(38, 8, 14),
(41, 9, 14),
(42, 10, 14),
(40, 11, 14),
(44, 12, 14),
(29, 13, 14),
(43, 15, 14),
(46, 16, 14),
(30, 17, 14),
(49, 18, 14),
(51, 19, 14),
(50, 20, 14),
(48, 21, 14),
(54, 22, 13),
(55, 23, 13),
(56, 24, 13),
(57, 25, 13),
(58, 26, 13);

-- --------------------------------------------------------

--
-- Table structure for table `product_flavors`
--

CREATE TABLE `product_flavors` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `flavor_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_flavors`
--

INSERT INTO `product_flavors` (`id`, `product_id`, `flavor_id`) VALUES
(13, 17, 4),
(11, 13, 6),
(12, 17, 5),
(103, 5, 24),
(102, 5, 23),
(101, 5, 22),
(100, 5, 21),
(99, 5, 20),
(98, 5, 19),
(97, 5, 18),
(96, 5, 17),
(95, 5, 16),
(94, 5, 15),
(93, 5, 14),
(92, 5, 13),
(91, 5, 12),
(90, 5, 11),
(89, 5, 10),
(88, 5, 9),
(87, 5, 8),
(86, 5, 7),
(104, 6, 25),
(105, 6, 26),
(106, 6, 27),
(107, 6, 28),
(108, 6, 29),
(109, 6, 30),
(110, 6, 31),
(111, 8, 27),
(112, 8, 28),
(113, 8, 30),
(114, 8, 31),
(115, 8, 32),
(116, 8, 33),
(117, 8, 34),
(118, 7, 5),
(119, 7, 10),
(120, 7, 20),
(121, 7, 27),
(122, 7, 31),
(123, 7, 32),
(124, 7, 33),
(125, 7, 35),
(126, 7, 37),
(127, 7, 38),
(128, 7, 39),
(129, 7, 40),
(130, 7, 41),
(131, 7, 42),
(132, 7, 43),
(133, 11, 10),
(134, 11, 31),
(135, 11, 37),
(136, 11, 44),
(137, 11, 45),
(138, 11, 46),
(139, 11, 47),
(140, 11, 49),
(141, 11, 50),
(142, 9, 51),
(143, 9, 52),
(144, 9, 53),
(145, 9, 54),
(146, 9, 55),
(147, 9, 56),
(148, 9, 57),
(149, 9, 58),
(150, 9, 59),
(151, 9, 60),
(152, 9, 61),
(153, 9, 62),
(154, 9, 63),
(155, 9, 64),
(156, 10, 18),
(157, 10, 65),
(158, 10, 66),
(159, 10, 67),
(160, 10, 68),
(161, 15, 69),
(162, 15, 70),
(163, 15, 71),
(164, 15, 72),
(165, 15, 73),
(166, 15, 74),
(167, 15, 75),
(168, 15, 76),
(169, 12, 7),
(170, 12, 38),
(176, 16, 78),
(175, 16, 77),
(174, 16, 38),
(177, 16, 79),
(178, 16, 80),
(179, 16, 81),
(183, 21, 32),
(182, 21, 25),
(184, 21, 82),
(185, 21, 83),
(186, 18, 27),
(187, 18, 33),
(188, 18, 37),
(189, 18, 84),
(190, 18, 85),
(191, 20, 86),
(192, 20, 87),
(193, 19, 88),
(194, 19, 89),
(195, 19, 90),
(196, 19, 91),
(197, 19, 92),
(198, 19, 93),
(199, 19, 94),
(253, 22, 24),
(252, 22, 23),
(251, 22, 22),
(250, 22, 21),
(249, 22, 20),
(248, 22, 19),
(247, 22, 18),
(246, 22, 17),
(245, 22, 16),
(244, 22, 15),
(243, 22, 14),
(242, 22, 13),
(241, 22, 12),
(240, 22, 11),
(239, 22, 10),
(238, 22, 9),
(237, 22, 8),
(236, 22, 7),
(254, 23, 95),
(255, 23, 96),
(256, 23, 97),
(257, 23, 98),
(258, 23, 99),
(259, 23, 100),
(260, 23, 101),
(261, 23, 102),
(262, 23, 103),
(263, 23, 104),
(264, 23, 105),
(265, 24, 25),
(266, 24, 26),
(267, 24, 27),
(268, 24, 28),
(269, 24, 29),
(270, 24, 30),
(271, 24, 31),
(272, 25, 106),
(273, 25, 107),
(274, 25, 108),
(275, 25, 109),
(276, 26, 110),
(277, 26, 111),
(278, 26, 112),
(279, 26, 113),
(280, 26, 114),
(281, 26, 115),
(282, 26, 116),
(283, 26, 117),
(284, 26, 118),
(285, 26, 119),
(286, 26, 120);

-- --------------------------------------------------------

--
-- Table structure for table `product_packages`
--

CREATE TABLE `product_packages` (
  `id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `package_id` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_packages`
--

INSERT INTO `product_packages` (`id`, `product_id`, `package_id`) VALUES
(7, 13, 4),
(8, 17, 4),
(12, 5, 5),
(13, 5, 6),
(14, 6, 4),
(15, 8, 4),
(16, 7, 4),
(17, 11, 4),
(18, 9, 4),
(19, 10, 7),
(20, 15, 4),
(21, 12, 4),
(23, 16, 9),
(25, 21, 4),
(26, 18, 10),
(27, 18, 11),
(28, 20, 4),
(29, 19, 7),
(33, 22, 12),
(32, 22, 1),
(34, 23, 1),
(35, 23, 12),
(36, 24, 13),
(37, 24, 14),
(38, 25, 3),
(39, 26, 4);

-- --------------------------------------------------------

--
-- Table structure for table `product_special_options`
--

CREATE TABLE `product_special_options` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `possible_values` longtext,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created`, `modified`) VALUES
(2, 'ericbloom', '$2a$10$D3MaYxUR0izpQXcGMmeaUOiROs38Foii.mCTBMlS9RwZRH.G1F57S', 'admin', '2017-06-30 12:06:27', '2017-06-30 12:06:27'),
(3, 'KurtMiller', '$2a$10$0fyMZd6CblC5ZKOBu18OBOoTQbdjtbCcHAc0EWce5VvknzRhq9E5a', 'admin', '2017-07-20 13:01:38', '2017-07-20 13:01:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flavors`
--
ALTER TABLE `flavors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_flavors`
--
ALTER TABLE `product_flavors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_packages`
--
ALTER TABLE `product_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_special_options`
--
ALTER TABLE `product_special_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `flavors`
--
ALTER TABLE `flavors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;
--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `product_flavors`
--
ALTER TABLE `product_flavors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=287;
--
-- AUTO_INCREMENT for table `product_packages`
--
ALTER TABLE `product_packages`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `product_special_options`
--
ALTER TABLE `product_special_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
