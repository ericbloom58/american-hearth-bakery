-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2017 at 10:53 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ahb`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `blog` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `name`, `blog`, `created`, `modified`) VALUES
(1, 'test page 1', '<p>okjay<img class="" src="/files/random%20images/elitelacross.jpg" alt="" width="496" height="110" /></p>\r\n<p>okay</p>', '2017-06-30 15:07:06', '2017-06-30 15:07:06');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Cookies Small', 'Two and a half to Three inch cookies.'),
(2, 'Cookies', 'Cookies Sold by Pound'),
(3, 'Brownies', '8" x 12" Brownies that come in 1/4 sheets.'),
(4, 'Bagels', '5oz Bagels available by the Dozen.'),
(9, 'Bread', 'Bread is goood');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `page_type` varchar(255) NOT NULL DEFAULT 'content',
  `linked_gallery` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `name`, `content`, `created`, `modified`, `page_type`, `linked_gallery`) VALUES
(9, 'About Us', '<p><span class="dropcap dropcap-default ">A</span>merican Heath Bakery began life in a downtown Baltimore kitchen in 1989 making fresh scones for local coffee shops. By 2008 it had grown (sometimes painfully) and evolved into a premier baker of 190 different items which consist of muffins, cookies, brownies, danish, pastries, N.Y. style bagels, sandwich bread, granola and much more. All made fresh six days a week. They are known as the pre-eminent DC/Baltimore bakery with the highest quality of such an extensive selection of baked goods, initially sold only wholesale to coffee shops, delicatessens, hospitals, universities and caterers. In 2007 the company began an eighteen month project to eliminate an extensive list of unacceptable food ingredients from its recipes without significantly increasing costs and without sacrificing flavor. By 2008 over 95% of its sales are now&nbsp;<strong>"Chemical Free", "All Natural" and with "No Artificial Flavors or Coloring".</strong>&nbsp;All products now have labels available with ingredients, nutritional values and bar codes. Early in 2008 they introduced their products packaged and labeled, available fresh, par-baked and frozen raw or fully baked to distributors, gourmet and whole food markets.&nbsp;<br /><br />American Hearth Bakery today is a multimillion dollar "small business\' Even in the most unstable economic times in the United States,&nbsp;<strong>the company has had no bank debt and pays all its bills in 7 days or less.</strong>&nbsp;It is owned by Kurt Miller who had been retired five years before buying the bakery in 2003, known then as A. Scone Co., as a challenge to retired life. Miller had to redesign and rebuild everything about the company. Replacing all the employees (except one, Paul Nygren, the manager and head baker), initiated modern bookkeeping, all new recipes and back-ups for all critical functions but most importantly creating an atmosphere where everybody can maximize their own personal potential in a "family" atmosphere where everybody looks forward to coming to work. They all work hard to please their customers and make them feel a part of the American Heath Bakery Team.</p>', '2017-07-20 11:56:43', '2017-07-20 12:56:26', 'content', ''),
(10, 'Home', '<p>Here is a short description about the local gem that is American Hearth Bakery</p>', '2017-07-20 12:03:12', '2017-07-26 18:34:10', 'content', ''),
(11, 'Unacceptable Ingredients', '<p>Our goal is to provide the highest quality, best tasting and safest products possible at an economical price. The Majority of our baked goods (although, not all) have no artificial additives, sweeteners, colorings, preservatives, or hydrogenated fats. Our "clean label" products have a heart printed on the label and on the price list. In addition, there are no peanuts or peanut products processed in any of our facilities. We also, buy and use cage free/hormone free dairy and poultry ingredients.</p>\r\n<p><br /><br /></p>\r\n<p>&nbsp;</p>\r\n<center><strong>Unacceptable Food Ingredients</strong></center>\r\n<p>&nbsp;</p>\r\n<div class="dt-sc-one-half column first">\r\n<ul>\r\n<li>acesulfame-K (acesulfame potassium)</li>\r\n<li>acetylated esters of mono- and diglycerides</li>\r\n<li>ammonium chloride</li>\r\n<li>artificial colors</li>\r\n<li>artificial flavors</li>\r\n<li>aspartame</li>\r\n<li>azodicarbonamide</li>\r\n<li>benzoates in foods</li>\r\n<li>benzoyl peroxide</li>\r\n<li>BHA (butylated hydroxyanisole)</li>\r\n<li>BHT (Butylated hydroxytoluene)</li>\r\n<li>bleached flour</li>\r\n<li>bromated flour</li>\r\n<li>brominated vegetable oil (BVO)</li>\r\n<li>calcium bromate</li>\r\n<li>calcium disodium EDTA</li>\r\n<li>calcium peroxide</li>\r\n<li>calcium propionate</li>\r\n<li>calcium saccharin</li>\r\n<li>calcium sorbate</li>\r\n<li>calcium stearoyl-2-lactylate</li>\r\n<li>DATEM (Diacetyl tartaric and fatty acid esters of mono and diglycerides)</li>\r\n<li>dimethylpolysiloxane</li>\r\n<li>dioctyl sodium sulfosuccinate (DSS)</li>\r\n<li>disodium calcium EDTA</li>\r\n<li>disodium dihydrogen EDTA</li>\r\n<li>disodium guanylate</li>\r\n<li>disodium inosinate</li>\r\n<li>EDTA</li>\r\n<li>ethyl vanillin</li>\r\n<li>ethylene oxide</li>\r\n<li>ethyoxyquin</li>\r\n<li>FD &amp; C colors</li>\r\n<li>GMP (disodium guanylate)</li>\r\n<li>High Fructose Corn Syrup</li>\r\n<li>hex-, hepta- and octa-esters of sucrose</li>\r\n<li>hydrogenated fats</li>\r\n<li>IMP (disodium inosinate)</li>\r\n<li>irradiated foods</li>\r\n</ul>\r\n</div>\r\n<div class="dt-sc-one-half column">\r\n<ul>\r\n<li>lactylated esters of mon- and</li>\r\n<li>diglycerides</li>\r\n<li>lead soldered cans</li>\r\n<li>methyl silicon</li>\r\n<li>methylparaben</li>\r\n<li>microparticularized whey protein derived fat substitute</li>\r\n<li>monosodium glutamate (MSG)</li>\r\n<li>natamyacin</li>\r\n<li>nitrates/nitrites</li>\r\n<li>partially hydrogenated oil</li>\r\n<li>polydextrose</li>\r\n<li>potassium benzoate</li>\r\n<li>potassium bisulfite</li>\r\n<li>potassium bromate</li>\r\n<li>potassium metabisulfite</li>\r\n<li>potassium sorbate</li>\r\n<li>propionates</li>\r\n<li>propyl gallate</li>\r\n<li>propylparaben</li>\r\n<li>saccharin</li>\r\n<li>soduium aluminum phosphate</li>\r\n<li>sodium aluminum sulfate</li>\r\n<li>sodium benzoate</li>\r\n<li>sodium bisulfite</li>\r\n<li>sodium diacetate</li>\r\n<li>sodium glutamate</li>\r\n<li>sodium nitrate/nitrite</li>\r\n<li>sodium propionate</li>\r\n<li>sodium stearoyl-2-lactylate</li>\r\n<li>sodium sulfite</li>\r\n<li>solvent extracted oils, as stand alone single-ingredient oils (except grapeseed oil)</li>\r\n<li>sorbic acid</li>\r\n<li>sucralose</li>\r\n<li>sucroglycerides</li>\r\n<li>sucrose polyester</li>\r\n<li>sulfites (sulfur dioxide)</li>\r\n<li>TBHQ (tertiary butylhydroquinone)</li>\r\n<li>tetrasodium EDTA</li>\r\n<li>vanillin</li>\r\n</ul>\r\n</div>', '2017-07-20 12:56:59', '2017-07-20 12:59:32', 'content', '');

-- --------------------------------------------------------

--
-- Table structure for table `flavors`
--

CREATE TABLE `flavors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flavors`
--

INSERT INTO `flavors` (`id`, `name`, `description`, `created`) VALUES
(1, 'Chocolate', '', '2017-07-27 00:00:00'),
(2, 'Vanilla', '', '2017-07-27 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`) VALUES
(1, 'Dozen'),
(2, 'Pound');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `body` longtext,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created`, `modified`, `user_id`) VALUES
(1, 'Test1', 'Testing', '2017-06-29 13:22:39', '2017-06-29 13:22:39', NULL),
(2, 'Test2', 'Testies', '2017-06-29 13:22:52', '2017-06-29 13:22:52', NULL),
(3, 'Test3', 'Tastey', '2017-06-29 13:23:09', '2017-06-29 13:23:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`) VALUES
(3, 'tester', '<p>testies</p>'),
(2, 'Test', '<p>Here ya go</p>');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `category_id` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `product_id`, `category_id`) VALUES
(10, 3, 1),
(9, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `product_flavors`
--

CREATE TABLE `product_flavors` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `flavor_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_flavors`
--

INSERT INTO `product_flavors` (`id`, `product_id`, `flavor_id`) VALUES
(8, 2, 2),
(7, 2, 1),
(9, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `product_packages`
--

CREATE TABLE `product_packages` (
  `id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `package_id` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_packages`
--

INSERT INTO `product_packages` (`id`, `product_id`, `package_id`) VALUES
(4, 2, 2),
(5, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `product_special_options`
--

CREATE TABLE `product_special_options` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `possible_values` longtext,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created`, `modified`) VALUES
(2, 'ericbloom', '$2a$10$D3MaYxUR0izpQXcGMmeaUOiROs38Foii.mCTBMlS9RwZRH.G1F57S', 'admin', '2017-06-30 12:06:27', '2017-06-30 12:06:27'),
(3, 'KurtMiller', '$2a$10$0fyMZd6CblC5ZKOBu18OBOoTQbdjtbCcHAc0EWce5VvknzRhq9E5a', 'admin', '2017-07-20 13:01:38', '2017-07-20 13:01:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flavors`
--
ALTER TABLE `flavors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_flavors`
--
ALTER TABLE `product_flavors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_packages`
--
ALTER TABLE `product_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_special_options`
--
ALTER TABLE `product_special_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `flavors`
--
ALTER TABLE `flavors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `product_flavors`
--
ALTER TABLE `product_flavors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `product_packages`
--
ALTER TABLE `product_packages`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `product_special_options`
--
ALTER TABLE `product_special_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
